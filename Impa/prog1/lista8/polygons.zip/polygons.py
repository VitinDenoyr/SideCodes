import csv
import turtle
import time

#--------------------------------------------------------------------------------------

#Problema 4
class Point2D: #Cria a classe Point2D
	def __init__(self, x:float, y:float):
		self.coord = [x,y]

class Polygon: #Cria a classe Polygon
	def __init__(self, points:list, color:str):
		self.points = points.copy()
		self.color = color

class Polygons:
	def __init__(self): #Inicialização
		self.polygons = []
	def addPolygon(self, polygon:Polygon, name:str):
		self.polygons += [[polygon,name]] #Adiciona em polygons o poligono e o seu nome
	def removePolygon(self, name:str):
		for i in range(len(self.polygons)): #Procura na lista o poligono com esse nome
			if self.polygons[i][1] == name: #Assim que o encontrar, remove esse indice da lista
				return self.polygons.pop(i)
	def save_to_file(self, filename:str):
		with open(filename, 'w', newline='') as csvf: #Abre o arquivo no modo de escrita evitando linhas vazias
			csvWrite = csv.writer(csvf) #Abre o writer
			for p in self.polygons: #Cada polígono tem uma linha, contendo seu nome, cor, quantidade de pontos e os pontos em seguida no formato de coordenada x, coordenada y
				r = [p[1],p[0].color]
				for pt in p[0].points:
					r += [pt.coord[0],pt.coord[1]]
				csvWrite.writerow(r)
	def load_from_file(self, filename:str):
		with open(filename, 'r') as csvf: #Abre o arquivo no modo de leitura
			csvRead = csv.reader(csvf) #Abre o reader
			self.polygons.clear() #Limpa o antigo polygons
			for line in csvRead:
				name = line[0] #Nome
				color = line[1] #Cor
				pt = [] #Pt vai guardar as coordenadas de um ponto
				pts = [] #Pts vai guardar os pontos para criar o poligono referente a essa linha
				for i in range(2,len(line)): #Pega o restante da linha, que são as coordenadas do ponto
					pt += [float(line[i])]
					if i%2 == 1: #Tem duas coordenadas em pt, então cria um ponto
						pts += [Point2D(pt[0],pt[1])]
						pt = []
				self.polygons += [[Polygon(pts,color),name]] #Adiciona um poligono dessa linha
	#Problema 5
	def plotPoints(self):
		#Primeiro, vamos ver quais as coordenadas minimas e maximas para criar a tela
		minX = 0; minY = 0; maxX = 0; maxY = 0
		for p in self.polygons: #Encontra a menor coordenada de todas x,y e a maior também, e com base nela, seta a tela
			if p is self.polygons[0]: #Se for o primeiro já é minimo
				minX = min(p[0].points, key=lambda q: q.coord[0]).coord[0]
				minY = min(p[0].points, key=lambda q: q.coord[1]).coord[1]
				maxX = max(p[0].points, key=lambda q: q.coord[0]).coord[0]
				maxY = max(p[0].points, key=lambda q: q.coord[1]).coord[1]
			else: #Só troca se for menor
				minX = min(min(p[0].points, key=lambda q: q.coord[0]).coord[0],minX)
				minY = min(min(p[0].points, key=lambda q: q.coord[1]).coord[1],minY)
				maxX = max(max(p[0].points, key=lambda q: q.coord[0]).coord[0],maxX)
				maxY = max(max(p[0].points, key=lambda q: q.coord[1]).coord[1],maxY)

		#Configurações padrão: Criar tela, colocar fundo e tamanho
		scr = turtle.Screen() #Cria tela
		dx = (maxX - minX)/6; dy = (maxY - minY)/6
		scr.setworldcoordinates(minX-dx, minY-dy, maxX+dx, maxY+dy) #Tamanho da tela
		scr.bgcolor("black") #Fundo preto

		tr = [] #Guarda todas as tartarugas, uma para cada polígono
		for i in range(len(self.polygons)):
			tr += [turtle.Turtle()] #Criando tartaruga
		
		for i in range(len(tr)):
			pol = self.polygons[i][0] #i-esimo poligono 
			ptlast = pol.points[len(pol.points)-1].coord
			tr[i].hideturtle() #Esconde o ponteirinho da tartaruga
			tr[i].pencolor(pol.color) #Cor dele
			tr[i].pensize(3) #Deixa mais visível
			tr[i].speed(10) #Deixa na velocidade agradável do desenho
			tr[i].teleport(ptlast[0],ptlast[1]) #Move para o início, que é o último ponto
			for j in range(len(pol.points)):
				pti = pol.points[j].coord #Ponto i
				tr[i].goto(pti[0],pti[1]) #Move para o ponto certo
		time.sleep(3)
		scr.clearscreen()
		

print("Testes de execução:")
print("Criação de retângulo azul...")
p1 = Polygon([Point2D(1,1),Point2D(1,3),Point2D(3,3),Point2D(3,1)],"blue")
print("Criado com Sucesso!")
print("Criação de retângulo vermelho contido no azul...")
p2 = Polygon([Point2D(1,2),Point2D(2,1),Point2D(3,2),Point2D(2,3)],"red")
print("Criado com Sucesso!")
print("Criação de retângulo roxo contido no vermelho...")
p3 = Polygon([Point2D(1.5,1.5),Point2D(1.5,2.5),Point2D(2.5,2.5),Point2D(2.5,1.5)],"purple")
print("Criado com Sucesso!")
print("Criação da classe polygons...")
p = Polygons()
print("Criado com Sucesso!")

print("Adicionando retângulo azul em polygons... Deve resultar em um retângulo de pontos [(1,1),(1,3),(3,3),(3,1)]")
p.addPolygon(p1,"poligono1")
print("Adicionando retângulo vermelho em polygons... Deve resultar em um retângulo de pontos [(1,2),(2,1),(3,2),(2,3)]")
p.addPolygon(p2,"polinogo2")
print("Adicionando retângulo roxo em polygons... Deve resultar em um retângulo de pontos [(1.5,1.5),(1.5,2.5),(2.5,2.5),(2.5,1.5)]")
p.addPolygon(p3,"poligono3")
print("Adicionados com sucesso!")

print("Protocolo de salvar polygon em polis.csv")
p.save_to_file("polis.csv")
print("Adicionando duplicata de retângulo azul para verificar se o protocolo de carregar arquivo funciona")
p.addPolygon(p1,"extrapoligono")

print("Carregando arquivo polis.csv")
p.load_from_file("polis.csv")

print("Executando função plotPoints que deverá desenhar apenas os três retangulos na tela... Dados os pontos fornecidos, a saída deve conter um retângulo roxo contido em um vermelho contido em um azul")
p.plotPoints()
