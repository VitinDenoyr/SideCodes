from polygons import csv, turtle, time, Point2D, Polygon, Polygons

#--------------------------------------------------------------------------------------

#Problema 1
def fuseLists(l1, l2): #Função de fundir duas listas
	s1 = len(l1)
	s2 = len(l2)
	i1 = 0 #Indice na l1
	i2 = 0 #Indice na l2
	l3 = [] #Lista resultante
	while(i1 < s1 and i2 < s2): #Primeiro, verifica o primeiro não adicionado de cada lista, que é o maior
		if l1[i1] >= l2[i2]: #Insere o maior na lista e move o ponteiro dessa lista para a frente
			l3 += [l1[i1]]
			i1 += 1
		else: #Faz o mesmo com l2
			l3 += [l2[i2]]
			i2 += 1
	while(i1 < s1): #Se chegou aqui, uma lista já acabou. Se ela for l2, isso vai executar e completar com l1
		l3 += [l1[i1]]
		i1 += 1
	while(i2 < s2): #Caso l1 que acabou, então completa com l2
		l3 += [l2[i2]]
		i2 += 1
	#Agora garantimos que as duas listas já acabaram.
	#Como cada termo foi adicionado só uma vez e cada adição faz no máximo 2 verificações e algumas operações em relação a cada um dos n termos de uma lista e dos m termos de outras, o código é O(n+m), proporcional ao total de termos nas duas listas
	return l3
'''print(fuseLists([19,13,12,11,5,3],[17,16,10,9,1]))'''

#--------------------------------------------------------------------------------------

#Problema 2
def resolveCompras(n:int, k:int, e:list): #Algoritmo em O(n*k) visto que não foi pedido uma complexidade, mas é possível fazer em O(n)
	qtd = [0]*n #Array que marca quantas vezes comprei o item i nas últimas k compras
	queue = [] #Improviso de fila que guarda os tipos dos ultimos k itens
	total = 0
	for i in range(n): #Executa n vezes: O(n)
		if qtd[e[i]] == 0: #Posso adicionar pois não há esse item nos anteriores
			qtd[e[i]] += 1 #Há um item a mais
			queue = [e[i]] + queue #Adiciona na fila com o número dos k itens em ordem
			total += 1 #Total de itens comprados aumenta
			if len(queue) > k: #Caso existam mais de k itens anteriores nessa iteração, desconsidere o item há k+1 iterações atras na quantidade
				last = queue.pop()
				qtd[last] -= 1
	return total
'''print(resolveCompras(10,3,[5,1,2,6,2,5,5,1,7,5]))'''
	
#--------------------------------------------------------------------------------------

#Problema 3
def verificaString(st:str):
	qtOpen = 0 #Quantos parenteses estão abertos
	for i in range(len(st)):
		if st[i] == '(':
			qtOpen += 1 #Tem mais um parentese aberto
		elif st[i] == ')':
			qtOpen -= 1 #Foi fechado um parentese
		if qtOpen < 0: #Se tem mais fechados que abertos, não é valida
			return False
	return qtOpen == 0 #Se depois de passar por todos os caracteres, não tiver nenhum parentese aberto, é valida
print(verificaString('Eu(so(u(mestre)))(dos)(magos)'))

#--------------------------------------------------------------------------------------

#Problemas 4 e 5
#Script de Execução do módulo polygons

def funcaoImpatecana(): #Função de execução: Utiliza o módulo polygons para desenhar a logo do impatech e o texto IMPA TECH abaixo.
	polygons = [
		Polygon([ #Logo 1
			Point2D(0.3, 2), Point2D(0.3, 1.6), Point2D(0.3, 1.2),
			Point2D(0.7, 1.2), Point2D(1.1, 1.2),
			Point2D(1.1, 1.6), Point2D(1.1, 2), Point2D(0.7, 2)
		], 'blue'),
		Polygon([ #Logo 2
			Point2D(1.2,2),Point2D(1.4,2),Point2D(1.6,2),Point2D(1.8,2),Point2D(2,2),
			Point2D(2,1.8),Point2D(2,1.6),Point2D(2,1.4),Point2D(2,1.2),
			Point2D(1.8,1.24),Point2D(1.6,1.32),Point2D(1.44,1.44),Point2D(1.32,1.6),Point2D(1.24,1.8)
		],'blue'),
		Polygon([ #Logo 3
			Point2D(2.1, 1.6), Point2D(2.14, 1.8), Point2D(2.22, 1.88), Point2D(2.3, 1.96),
			Point2D(2.5, 2), Point2D(2.7, 1.96), Point2D(2.78, 1.88), Point2D(2.86, 1.8),
			Point2D(2.9, 1.6), Point2D(2.86, 1.4), Point2D(2.78, 1.32), Point2D(2.7, 1.24),
			Point2D(2.5, 1.2), Point2D(2.3, 1.24), Point2D(2.22, 1.32), Point2D(2.14, 1.4)
		], 'blue'),
		Polygon([ #I
			Point2D(0,1),Point2D(0,0.8),Point2D(0,0.6),Point2D(0,0.4),Point2D(0,0.2),Point2D(0,0),
			Point2D(0.2,0),Point2D(0.2,0.2),Point2D(0.2,0.4),Point2D(0.2,0.6),Point2D(0.2,0.8),Point2D(0.2,1),
		],'green'),
		Polygon([ #M
			Point2D(0.4,1),Point2D(0.4,0.8),Point2D(0.4,0.6),Point2D(0.4,0.4),Point2D(0.4,0.2),Point2D(0.4,0),
			Point2D(0.6,0),Point2D(0.6,0.2),Point2D(0.6,0.4),Point2D(0.6,0.6),Point2D(0.7,0.4),Point2D(0.8,0.2),Point2D(0.9,0),Point2D(1,0.2),Point2D(1.1,0.4),Point2D(1.2,0.6),Point2D(1.2,0.4),Point2D(1.2,0.2),Point2D(1.2,0),
			Point2D(1.4,0),Point2D(1.4,0.2),Point2D(1.4,0.4),Point2D(1.4,0.6),Point2D(1.4,0.8),Point2D(1.4,1),
			Point2D(1.2,1),Point2D(1.1,0.8),Point2D(1,0.6),Point2D(0.9,0.4),Point2D(0.8,0.6),Point2D(0.7,0.8),Point2D(0.6,1)
		],'green'),
		Polygon([ #P
			Point2D(1.6,1),Point2D(1.6,0.8),Point2D(1.6,0.6),Point2D(1.6,0.4),Point2D(1.6,0.2),Point2D(1.6,0),Point2D(1.8,0),Point2D(1.8,0.2),Point2D(1.8,0.4),Point2D(2,0.4),Point2D(2.2,0.6),Point2D(2.2,0.8),Point2D(2,1),Point2D(1.8,1)
		],'green'),
		Polygon([ #P -> Contorno interno
			Point2D(1.8,0.8),Point2D(1.8,0.6),Point2D(2,0.6),Point2D(2,0.8)
		],'green'),
		Polygon([ #A
			Point2D(2.4,0.8),Point2D(2.4,0.6),Point2D(2.4,0.4),Point2D(2.4,0.2),Point2D(2.4,0),Point2D(2.6,0),Point2D(2.6,0.2),Point2D(2.6,0.4),Point2D(2.8,0.4),Point2D(3,0.4),Point2D(3,0.2),Point2D(3,0),Point2D(3.2,0),Point2D(3.2,0.2),Point2D(3.2,0.4),Point2D(3.2,0.6),Point2D(3.2,0.8),Point2D(3,1),Point2D(2.8,1),Point2D(2.6,1),
		],'green'),
		Polygon([ #A -> Contorno interno
			Point2D(2.6,0.8),Point2D(2.6,0.6),Point2D(3,0.6),Point2D(3,0.8)
		],'green'),
		Polygon([ #T
			Point2D(0.1, -0.2), Point2D(0.1, -0.4), Point2D(0.3, -0.4), Point2D(0.3, -0.6), Point2D(0.3, -0.8), Point2D(0.3, -1),
			Point2D(0.3, -1.2), Point2D(0.5, -1.2), Point2D(0.5, -1), Point2D(0.5, -0.8), Point2D(0.5, -0.6), Point2D(0.5, -0.4),
			Point2D(0.7, -0.4), Point2D(0.7, -0.2), Point2D(0.5, -0.2), Point2D(0.3, -0.2)
		], 'yellow'),
		Polygon([ #E
			Point2D(0.9, -0.2), Point2D(0.9, -0.4), Point2D(0.9, -0.6), Point2D(0.9, -0.8), Point2D(0.9, -1), Point2D(0.9, -1.2),
			Point2D(1.1, -1.2), Point2D(1.3, -1.2), Point2D(1.5, -1.2), Point2D(1.5, -1), Point2D(1.3, -1), Point2D(1.1, -1),
			Point2D(1.1, -0.8), Point2D(1.3, -0.8), Point2D(1.5, -0.8), Point2D(1.5, -0.6), Point2D(1.3, -0.6), Point2D(1.1, -0.6),
			Point2D(1.1, -0.4), Point2D(1.3, -0.4), Point2D(1.5, -0.4), Point2D(1.5, -0.2), Point2D(1.3, -0.2), Point2D(1.1, -0.2)
		], 'yellow'),
		Polygon([ #C
			Point2D(1.7, -0.2), Point2D(1.7, -0.4), Point2D(1.7, -0.6), Point2D(1.7, -0.8), Point2D(1.7, -1), Point2D(1.7, -1.2),
			Point2D(1.9, -1.2), Point2D(2.1, -1.2), Point2D(2.3, -1.2), Point2D(2.3, -1), Point2D(2.1, -1), Point2D(1.9, -1),
			Point2D(1.9, -0.8), Point2D(1.9, -0.6), Point2D(1.9, -0.4), Point2D(2.1, -0.4), Point2D(2.3, -0.4), Point2D(2.3, -0.2),
			Point2D(2.1, -0.2), Point2D(1.9, -0.2)
		], 'yellow'),
		Polygon([ #H
			Point2D(2.5, -0.2), Point2D(2.5, -0.4), Point2D(2.5, -0.6), Point2D(2.5, -0.8), Point2D(2.5, -1), Point2D(2.5, -1.2),
			Point2D(2.7, -1.2), Point2D(2.7, -1), Point2D(2.7, -0.8), Point2D(2.9, -0.8), Point2D(2.9, -1), Point2D(2.9, -1.2),
			Point2D(3.1, -1.2), Point2D(3.1, -1), Point2D(3.1, -0.8), Point2D(3.1, -0.6), Point2D(3.1, -0.4), Point2D(3.1, -0.2),
			Point2D(2.9, -0.2), Point2D(2.9, -0.4), Point2D(2.9, -0.6), Point2D(2.7, -0.6), Point2D(2.7, -0.4), Point2D(2.7, -0.2),
		], 'yellow')
	]
	poly = Polygons()
	for p in polygons:
		poly.addPolygon(p,f"x{len(poly.polygons)+1}") #Adiciona os poligonos com nomes x1 ... xn
	poly.plotPoints() #Executa plot points
funcaoImpatecana()